data di-input melalui file data.txt

cara meng-input data yaitu dengan dengan menusliskan data tiap persamaan(koefisien dari variabel & konstanta)
ke dalam file data.txt

contoh: persamaan "ax + by + cz = d" maka data-nya adalah "a b c d"

sebagai contoh dari data yang akan ditulis di file data.txt yaitu:

	1 2 3 7
	4 5 6 8
	8 1 3 5

	dengan jumlah persamaan dan variabel harus sesuai dengan input di program.
